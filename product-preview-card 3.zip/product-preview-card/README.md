# Product Preview Card Component

Beginner-friendly HTML and CSS project based on the Frontend Mentor Product Preview Card Component challenge.

## Files
- `index.html` — page content
- `styles.css` — styling and responsive layout

## Important
The exact challenge product photos and cart icon are referenced from a public GitHub repository, so an internet connection is needed for those images to load.

## GitHub and Vercel
1. Create a GitHub repository named `product-preview-card`.
2. Upload `index.html`, `styles.css`, and `README.md` (do not upload only the ZIP).
3. Import the GitHub repository into Vercel and deploy it.


Image note: The exact Gabrielle Essence Eau de Parfum photo is loaded from a public online image source in `index.html`; an internet connection is required for it to display. The desktop and mobile versions are included in the responsive `<picture>` element.
